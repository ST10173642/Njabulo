/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog5121_poe;

/**
 *
 * @author ST10173642
 */
public class AssertEquals {
    
    public boolean correctTaskID(Task t, String id)
    {
        String id2 = t.createTaskID();
        if(id.equals(id2) == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean correctTotalDuration(Task[] t,int totalHours)
    {
        int totalDuration = 0;
        for (int i = 0; i < t.length; i++) {
            totalDuration += t[i].getDuration();
        }
        if(totalHours == totalDuration)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
